
# 类结构 simple_ml.base



## 模型类 simple_ml.base.base_model

### 结构体： BinaryTreeNode


## 枚举类 simple_ml.base.base_enum



## 异常类 simple_ml.base.base_error