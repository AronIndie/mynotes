# -*- coding:utf8 -*-
import datetime


class Candle:

    __doc__ = "1分钟线蜡烛图中的一根蜡烛线"

    def __init__(self, this_minute, tick_data):
        """
        默认时间格式为datetime.time()，如datetime.time(9,30,0)
        :param this_minute: 
        """
        self.candle_time = this_minute
        self.open_price = tick_data
        self.close_price = tick_data
        self.highest_price = tick_data
        self.lowest_price = tick_data
        self.is_rise = None
        self.is_full = False

    def add(self, time, tick_data):
        """
        添加tick数据，必须按照时间顺序添加
        :param time:        默认传入datetime.time格式的时间  
        :param tick_data:   跳价数据
        """
        if time.hour == self.candle_time.hour and time.minute == self.candle_time.minute:
            if tick_data > self.highest_price:
                self.highest_price = tick_data
            if tick_data < self.lowest_price:
                self.lowest_price = tick_data
            self.close_price = tick_data
        else:
            self.is_full = True
            self.add_over()

    def add_over(self):
        self.is_rise = True if self.close_price > self.open_price else False
        if self.is_rise:
            self.upper_price = self.close_price
            self.lower_price = self.open_price
        else:
            self.upper_price = self.open_price
            self.lower_price = self.close_price


class KLine:

    __doc__ = "记录n根蜡烛线的K线图"

    def __init__(self, n):
        self.length = n
        self.candle_list = []
        self.support_point = None
        self.pressure_point = None
        self.reset()

    def reset(self):
        self.support_point_change = False
        self.pressure_point_change = False

    def append(self, candle):
        if len(self.candle_list) == 5:
            self.candle_list.pop(0)
        self.candle_list.append(candle)
        self.get_pressure_point()
        self.get_support_point()

    def get_pressure_point(self):
        if len(self.candle_list) == 5:
            middle_price = self.candle_list[2].upper_price
            flag = True
            for i in self.candle_list:
                if middle_price < i.upper_price:
                    flag = False
                    break
            if flag:
                self.pressure_point_change = True
                self.pressure_point = self.candle_list[2]

    def get_support_point(self):
        if len(self.candle_list) == 5:
            middle_price = self.candle_list[2].lower_price
            flag = True
            for i in self.candle_list:
                if middle_price > i.lower_price:
                    flag = False
                    break
            if flag:
                self.support_point_change = True
                self.support_point = self.candle_list[2]


if __name__ == '__main__':
    import random
    import pandas as pd
    ticks = [(pd.to_datetime('09:00:01'), 8),
             (pd.to_datetime('09:00:30'), 10),
             (pd.to_datetime('09:00:59'), 10),
             (pd.to_datetime('09:01:00'), 10),
             (pd.to_datetime('09:01:59'), 7),
             (pd.to_datetime('09:02:01'), 6),
             (pd.to_datetime('09:02:59'), 9),
             (pd.to_datetime('09:03:01'), 8),
             (pd.to_datetime('09:03:59'), 10),
             (pd.to_datetime('09:04:01'), 10),
             (pd.to_datetime('09:04:59'), 10),
             (pd.to_datetime('09:05:59'), 10)]

    candle = []
    k_line = KLine(5)
    for time, ask_price in ticks:
        if not candle:
            candle = Candle(time, ask_price)
        candle.add(time, ask_price)

        if candle.is_full:
            k_line.append(candle)
            candle = Candle(time, ask_price)

    print k_line.pressure_point
