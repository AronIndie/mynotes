# -*- coding:utf-8 -*-

import sys
sys.path.append('../')
from abstract.myclassifier import *
import numpy as np

class MyBPNetwork(myClassifier):

    def __init__(self, alpha=0.1, iter_times=1000, hidden_layer=1, hidden_neuron=4):
        super(MyBPNetwork, self).__init__()
        self.alpha = alpha
        self.iterTimes = iter_times
        self.hide_layer_amount = hidden_layer               # 多少层隐含层
        self.neuron_amount = hidden_neuron                 # 隐含层和输入层每层多少个神经元（简化问题，假设隐含层和输入层元数目一样）
        # 简化问题，假设输出层只有一个神经元
        self.__clear()
        self._initWandB()

    def __clear(self):
        # 三维数组存储权重，第一维表示第几层(包括了输入和输出层，没有则为0)，第二维表示起点，第三维表示终点
        self.w_hide = np.ndarray((self.hide_layer_amount, self.neuron_amount, self.neuron_amount))  # 隐含层权重（没有以输入层为终点的权重）
        self.b_hide = np.zeros((self.hide_layer_amount, self.neuron_amount))                     # 隐含层阈值（输入层没有阈值）
        self.z_hide = np.zeros((self.hide_layer_amount, self.neuron_amount))                     # 隐含层线性值（输入层没有线性结果）
        self.a_hide = np.zeros((self.hide_layer_amount, self.neuron_amount))                     # 隐含层激活

        self.w_output = np.zeros(self.neuron_amount)
        self.b_output = None
        self.z_output = None
        self.a_output = None

        self.delta_output = None                              # 输出层的误差
        self.delta_hidden = np.zeros((self.hide_layer_amount, self.neuron_amount))            # 隐含层的误差

    @staticmethod
    def _sigmoid(x):
        return 1 / (1 - np.exp(-x))

    @staticmethod
    def _sigmoidInv(p):
        return np.log(1 / (1 - p))

    def _initWandB(self):
        self.w_hide = np.array([np.random.normal(0,1) for i in self.w_hide.ravel()]).reshape(self.w_hide.shape)
        self.b_hide = np.array([np.random.normal(0,1) for i in self.b_hide.ravel()]).reshape(self.b_hide.shape)
        self.w_output = np.array([np.random.normal(0,1) for i in self.w_output])
        self.b_output = np.random.normal(0,1)

    def fit(self, X, Y):
        self._init(X, Y)
        self.x = self.X[0]
        self.y = self.Y[0]
        self._fit(self.iterTimes, self.alpha)

    def _forwardTransfer(self):
        """
        前向传递，根据w和b，计算出每一神经元的z和a
        """
        for layer_id in range(self.hide_layer_amount):
            for neuron_id in range(self.neuron_amount):
                if layer_id == 0:
                    self.z_hide[layer_id, neuron_id] = np.dot(self.w_hide[layer_id, :, neuron_id], \
                        self.x) + self.b_hide[layer_id, neuron_id]
                else:
                    self.z_hide[layer_id, neuron_id] = np.dot(self.w_hide[layer_id, :, neuron_id], \
                        self.a_hide[layer_id-1, :]) + self.b_hide[layer_id, neuron_id]
                self.a_hide[layer_id, neuron_id] = self._sigmoid(self.z_hide[layer_id, neuron_id])

        self.z_output = np.dot(self.w_output, self.a_hide[-1, :]) + self.b_output
        self.a_output = self._sigmoid(self.z_output)

    def _calOutputError(self):
        """
        根据公式1计算输出层的误差
        假设使用平方损失，则 J = (y_i - a_i)^2
        J' = -2(y_i - a_i)
        delta_output = -2(y_i - a_output) sigmiodInv(z_output)
        """
        self.delta_output = -2 * (self.y - self.a_output) * self._sigmoid(self.z_output)

    def _calHiddenError(self):
        """
        根据公式2计算隐含层误差
        """

        # step1. 计算最后一层 hiden layer 的误差
        self.delta_hidden[-1, :] = np.multiply(self.w_output * self.delta_output, self.z_hide[-1, :])

        # step. 计算其余各层的 误差

        for layer in range(self.hide_layer_amount-1):
            self.delta_hidden[layer, :] = np.multiply(np.dot(self.w_hide[layer+1, :, :].T, \
                                                             self.delta_hidden[layer+1, :]), self.z_hide[layer,:])

    def _updateParam(self, alpha):
        """
        根据误差更新w和b
        - b的更新梯度就是误差
        - w的更新梯度如下计算
        """
        self.w_hide_update = self.w_hide.copy()
        for layer in range(self.hide_layer_amount):
            if layer != 0:
                self.w_hide_update[layer, :, :]  = self.delta_hidden[layer, :] * self.a_hide[layer-1].reshape(-1, 1)
            else:
                self.w_hide_update[layer, :, :] = self.delta_hidden[layer, :] * self.x.reshape(-1,1)
        self.w_output_update = self.delta_output * self.a_hide[-1, :]

        for layer in range(self.hide_layer_amount):
            for i in range(self.neuron_amount):
                for j in range(self.neuron_amount):
                    self.w_hide[layer, i, j] -= alpha * self.w_hide_update[layer, i, j]
                self.b_hide[layer, i] -= alpha * self.delta_hidden[layer, i]

        self.w_output = self.w_output - alpha * self.w_output_update
        self.b_output = self.b_output - alpha * self.delta_output

    def _fit(self, iterTimes, alpha):
        for i in range(iterTimes):
            self._forwardTransfer()
            self._calOutputError()
            self._calHiddenError()
            self._updateParam(alpha)

    def predict(self, X):
        x = X[0]
        return self._predictSingle(x)

    def _predictSingle(self, x):
        z_hide_new = self.z_hide.copy()
        a_hide_new = self.a_hide.copy()
        for layer_id in range(self.hide_layer_amount):
            for neuron_id in range(self.neuron_amount):
                if layer_id == 0:
                    z_hide_new[layer_id, neuron_id] = np.dot(self.w_hide[layer_id, :, neuron_id], \
                        x) + self.b_hide[layer_id, neuron_id]
                else:
                    z_hide_new[layer_id, neuron_id] = np.dot(self.w_hide[layer_id, :, neuron_id], \
                        a_hide_new[layer_id-1, :]) + self.b_hide[layer_id, neuron_id]
                a_hide_new[layer_id, neuron_id] = self._sigmoid(z_hide_new[layer_id, neuron_id])

        z_output_new = np.dot(self.w_output, a_hide_new[-1, :]) + self.b_output
        a_output_new = self._sigmoid(z_output_new)
        return a_output_new

if __name__ == '__main__':
    np.random.seed(100)
    X = np.random.randn(10, 4)
    np.random.seed(100)
    Y = np.random.rand(10)
    bp = MyBPNetwork(iter_times=100)
    bp.fit(X,Y)
    print(bp.w_hide)
    print(Y[0])
    print(bp.predict(X))