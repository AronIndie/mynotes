# -*- coding:utf-8 -*-

import sys
sys.path.append('../')
import numpy as np
from numpy.linalg import norm
from knn.mysimpleknn import DisType

class MyKMeans(object):

    def __init__(self, k, dis_type=DisType.Eculidean, d=1):
        self.k = k
        self.disType = dis_type
        self.d = d

    def _getDisFunc(self, x1, x2):

        if self.disType == DisType.Eculidean:
            return norm(x1 - x2)
        elif self.disType == DisType.Manhattan:
            return norm(x1 - x2, 1)
        elif self.disType == DisType.Minkowski:
            return norm(x1 - x2, self.d)
        elif self.disType == DisType.Chebyshev:
            return norm(x1 - x2, np.inf)
        elif self.disType == DisType.CosSim:
            return np.dot(x1, x2) / (norm(x1) * norm(x2))
        else:
            raise Exception('No Such Distance Type')

    def _clear(self):
        self.variable_num = self.sample_num = 0
        self.X = None

    def _init(self, X):
        self._clear()
        self.variable_num = X.shape[1]
        self.sample_num = X.shape[0]
        self.X = X
        self._labels = np.zeros(self.sample_num)

    def fit(self, X):
        self._init(X)
        self._fit()

    @staticmethod
    def _centerIsChanged(center, updated_center):
        for i in range(center.shape[0]):
            if not np.array_equal(center[i], updated_center[i]):
                return True
        return False

    def _judgeSingleSample(self, idx, x, center_point):
        distances = list(map(lambda i: self._getDisFunc(x, i), center_point))
        if self.disType == DisType.CosSim:
            self._labels[idx] = np.argmax(distances)
        else:
            self._labels[idx] = np.argmin(distances)

    def _getNewCenter(self, old_center):
        new_center = old_center.copy()
        for i, label in enumerate(np.unique(self.labels)):
            new_center[i] = np.mean(self.X[self._labels == label, :], axis=0)
        return new_center

    def _fit(self):
        init_point_id = np.random.choice(np.arange(self.sample_num), self.k)

        center_point = X[init_point_id, :]
        center_update_point = center_point + 1

        while self._centerIsChanged(center_point, center_update_point):
            center_update_point = center_point
            for i, x in enumerate(self.X):
                self._judgeSingleSample(i, x, center_point)
            print(self._labels)
            center_point = self._getNewCenter(center_point)

    @property
    def labels(self):
        return self._labels

if __name__ == '__main__':
    X = np.array([1, 2,3, 5,6, 10,11,12,20, 35]).reshape(-1, 2)
    X = np.random.rand(*(50, 2))
    km = MyKMeans(3, DisType.Minkowski, d=2)
    km.fit(X)
    print(km.labels)

    # plot
    import matplotlib.pyplot as plt
    plt.scatter(x=X[:,0], y=X[:, 1], c=km.labels)
    plt.show()
