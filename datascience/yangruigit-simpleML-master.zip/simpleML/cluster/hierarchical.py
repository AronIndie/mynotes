# -*- coding:utf-8 -*-

import sys
sys.path.append('../')
import numpy as np
from numpy.linalg import norm
from knn.mysimpleknn import DisType


class ClusterNode(object):
    def __init__(self, left, right, parent, idxs, distance=0):
        self.left = left
        self.right = right
        self.parent = parent
        self.idxs = idxs        # 当前节点的所有样本编号
        self.distance = distance

class MyHierarchial(object):

    def __init__(self, dis_type=DisType.Eculidean, d=1):
        self.disType = dis_type
        self.d = d

    def _getDisFunc(self, x1, x2):

        if self.disType == DisType.Eculidean:
            return norm(x1 - x2)
        elif self.disType == DisType.Manhattan:
            return norm(x1 - x2, 1)
        elif self.disType == DisType.Minkowski:
            return norm(x1 - x2, self.d)
        elif self.disType == DisType.Chebyshev:
            return norm(x1 - x2, np.inf)
        elif self.disType == DisType.CosSim:
            return - np.dot(x1, x2) / (norm(x1) * norm(x2))
        else:
            raise Exception('No Such Distance Type')

    def _clear(self):
        self.variable_num = self.sample_num = 0
        self.X = None
        self.disMat = None
        self.root = None

    def _init(self, X):
        self._clear()
        self.variable_num = X.shape[1]
        self.sample_num = X.shape[0]
        self.X = X
        self._labels = np.arange(self.sample_num)

    def fit(self, X):
        self._init(X)
        self.root = self._fit()

    def _calDisMat(self):
        self.disMat = np.ones((self.sample_num, self.sample_num))
        for i in range(self.sample_num):
            for j in range(i+1, self.sample_num):
                self.disMat[i, j] = self._getDisFunc(self.X[i], self.X[j])
                self.disMat[j, i] = self.disMat[i, j]
            self.disMat[i, i] = 0.0

    def _disOfCluster(self, clusternode1:ClusterNode, clusternode2:ClusterNode):
        sum = 0.0
        count = 0.0
        for i in clusternode1.idxs:
            for j in clusternode2.idxs:
                sum += self.disMat[i, j]
                count += 1
        return sum / count

    def _getNearestId(self, candidate_list):
        min_dis = np.inf
        nearest_pair = (-1, -1)
        for i in range(len(candidate_list)):
            for j in range(i+1, len(candidate_list)):
                dis = self._disOfCluster(candidate_list[i], candidate_list[j])
                if dis < min_dis:
                    min_dis = dis
                    nearest_pair = (i, j)

        return nearest_pair, min_dis

    def _fit(self):

        # 1. 先计算出每个样本间的距离矩阵
        self._calDisMat()

        # 2. 每个样本看成一个簇， 每次循环把最接近的簇变成同一个簇，从下往上构成一个二叉树
        candidate_list = [ClusterNode(None, None, None, [i]) for i in range(self.sample_num)]
        while True:
            if len(candidate_list) == 1:
                break
            pair, dis = self._getNearestId(candidate_list)

            # 更新candidate_list
            left_node = candidate_list[pair[0]]
            right_node = candidate_list[pair[1]]
            new_cluster = ClusterNode(left_node, right_node, None, None, dis)
            new_cluster.idxs = left_node.idxs + right_node.idxs
            left_node.parent = new_cluster
            right_node.parent = new_cluster

            candidate_list.remove(left_node)
            candidate_list.remove(right_node)
            candidate_list.append(new_cluster)

        return candidate_list[0]

    def cluster(self, min_sim=None):
        if min_sim == None: min_sim = self.max_dis
        clusters = []
        self._recursion(self.root, min_sim, clusters)
        for i, cluster in enumerate(clusters):
            for j in cluster:
                self._labels[j] = i
        return self._labels

    @staticmethod
    def _recursion(node, threshold, clusters_list):
        if node.left == None or node.right == None:
            clusters_list.append(node.idxs)
            return

        if node.distance < threshold:
            # 此时跳出，并且记录当前的节点
            clusters_list.append(node.idxs)
            return

        MyHierarchial._recursion(node.left, threshold, clusters_list)
        MyHierarchial._recursion(node.right, threshold, clusters_list)

    @property
    def labels(self):
        return self._labels

    @property
    def max_dis(self):
        return self.root.distance

if __name__ == '__main__':
    X = np.array([1, 2,3, 5,6, 10,11,12,20, 35]).reshape(-1, 2)
    X = np.random.rand(*(50, 2))
    km = MyHierarchial(DisType.Minkowski, d=2)
    km.fit(X)
    print(km.max_dis)
    print(km.cluster(km.max_dis/4))


    # plot
    import matplotlib.pyplot as plt
    plt.scatter(x=X[:,0], y=X[:, 1], c=km.labels)
    plt.show()
