from sklearn import datasets


def get_iris():
    iris = datasets.load_iris()
    X = iris.data
    y = iris.target
    return X, y

def get_moon(samples):
    moons = datasets.make_moons(samples)
    return moons[0], moons[1]

def get_watermelon():
    import pandas as pd
    df = pd.read_csv(r'D:\cygwin64\home\document\mynotes\datascience\algorithm\dataset\watermelon.csv', header=-1, index_col=0, encoding='gbk')
    return df.values[:, :-1], df.values[:, -1]

if __name__ == '__main__':
    x, y = get_watermelon()
    