import numpy as np
from abc import ABCMeta, abstractmethod

class DecisionTree():
    def __init__(self):
        self.clear()

    def clear(self):
        self.X, self.Y = None, None

    def fit(self, X, Y):
        self.X, self.Y = X, Y
        self._fit()

    @abstractmethod
    def _fit(self):
        pass

    def score(self, X, Y):
        pass

    def predict(self, X):
        pass


class TreeNode:
    def __init__(self, left=None, right=None, dataId=[], leftFeatureId=[], value=None):
        self.left = left
        self.right = right
        self.dataId = dataId
        self.leftFeatureId= leftFeatureId
        self.value = value


class RegressionTree(DecisionTree):
    def __init__(self, min_leaf_samples=1):
        super(DecisionTree, self).__init__()
        self.min_leaf_samples = min_leaf_samples

    def _fit(self):
        self.root = self._genTree(TreeNode(None, None, list(range(self.X.shape[0])), list(range(self.X.shape[1])), None))

    def _genTree(self, inputNode=None):
        if len(inputNode.dataId) <= self.min_leaf_samples:
            return TreeNode(None, None, inputNode.dataId, None, np.mean(self.Y[inputNode.dataId]))

        best_split = self._getBestSplit(inputNode.dataId, inputNode.leftFeatureId)
        inputNode.leftFeatureId.remove(best_split[1])
        newLeftFeatureId = inputNode.leftFeatureId.copy()
        inputNode.value = best_split[2]
        if inputNode.left == None:
            left_node = TreeNode(None, None, best_split[3], newLeftFeatureId, None)
            inputNode.left = self._genTree(left_node)
        if inputNode.right == None:
            right_node = TreeNode(None, None, best_split[4], newLeftFeatureId, None)
            inputNode.right = self._genTree(right_node)
        return inputNode

    def _getBestSplit(self, dataId, leftFeatureId):
        best_split = (np.Inf, None, None, None, None)
        for featureId in leftFeatureId:
            unique_values = np.unique(self.X[:,featureId])
            for value in unique_values:
                le_data_id, ge_data_id = self._dataSplit(self.X, dataId, featureId, value)
                sum_sse = RegressionTree._getSumSSE(self.Y[le_data_id], self.Y[ge_data_id])
                if sum_sse < best_split[0]:
                    best_split = (sum_sse, featureId, value, le_data_id, ge_data_id)
        return best_split

    @staticmethod
    def _dataSplit(X, dataId, featureId, value):
        is_le_value = X[:, featureId] <= value
        is_ge_value = np.logical_not(is_le_value)
        le_data_id = np.intersect1d(np.arange(X.shape[0])[is_le_value], dataId)
        ge_data_id = np.intersect1d(np.arange(X.shape[0])[is_ge_value], dataId)
        return le_data_id, ge_data_id

    @staticmethod
    def _getSumSSE(ly, ry):
        return RegressionTree._getSSE(ly) + RegressionTree._getSSE(ry)

    @staticmethod
    def _getSSE(y):
        return np.sum(list(map(lambda x: (x-np.mean(y))**2, y)))

    def check(self,x):
        pass

    def predict(self, x):
        self.check(x)
        return self._predict(self.root, x, list(range(self.X.shape[1])))

    def _predict(self, node, x, total_feature):
        if node.left == None and node.right == None:
            return node.value

        which_feature = list(set(total_feature) - set(node.leftFeatureId))[0]
        if x[which_feature] <= node.value:
            return self._predict(node.left, x, node.leftFeatureId)
        else:
            return self._predict(node.right, x, node.leftFeatureId)


if __name__ == '__main__':
    np.random.seed(1234)
    rt = RegressionTree(3)
    X = np.random.rand(20, 10)
    Y = np.random.rand(20)
    y_test = np.random.rand(10)
    rt.fit(X, Y)
    print(rt.predict(y_test))
    from sklearn.tree import DecisionTreeRegressor
    dt = DecisionTreeRegressor(min_samples_leaf=3)
    dt.fit(X, Y)
    print(dt.predict(y_test.reshape(1, -1)))
    """
    结果产生出入原因：
    分割标准不一样
    默认参数不一样（事实上我只给出了一个默认参数min_leaf_sample)
    """



