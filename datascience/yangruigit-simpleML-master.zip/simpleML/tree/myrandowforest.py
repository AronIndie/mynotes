# -*- coding:utf-8 -*-

import sys
sys.path.append('..')
from abstract.myclassifier import *
from collections import Counter
from utils.score import *
import numpy as np
from dataset.classify_data import get_moon, get_iris

class MyRandomForest(myClassifier):

    def __init__(self, m, tree_num=200):
        super(MyRandomForest, self).__init__()
        self.m = m
        self.tree_num = tree_num
        self.forest = None

    def fit(self, X, Y):
        self._init(X, Y)
        assert self.m <= self.variable_num
        self._fit(X, Y)

    def _fit(self, X, Y):
        from sklearn.tree import DecisionTreeClassifier
        self.forest = [DecisionTreeClassifier() for i in range(self.tree_num)]
        self.feature_list = []
        for i, tree in enumerate(self.forest):
            random_X, random_y, select_features= self._sampleFromX(i) # 默认以当前树的编号作为随机种子，使每次运行时抽样结果完全一致
            tree.fit(random_X, random_y)
            self.feature_list.append(select_features)

    def _sampleFromX(self, seed):
        np.random.seed(seed)
        selected_sample_ids = np.random.randint(0, self.sample_num, self.sample_num)
        np.random.seed(seed)
        selected_feature_ids = np.random.choice(range(self.variable_num), self.m, False)
        random_X = self.X[selected_sample_ids, :]
        random_X = random_X[:, selected_feature_ids]
        random_Y = self.Y[selected_sample_ids]
        return random_X, random_Y, selected_feature_ids

    def predict(self, X):
        if self.forest == None:
            raise Exception("You need to FIT the model firstly.")

        # tree_num*sample_num 行为每一棵树的预测，列为对每一个样本的预测
        predict_results_mat = np.array([tree.predict(X[:, self.feature_list[i]])
                                        for i, tree in enumerate(self.forest)])
        return self._vote(predict_results_mat)

    def _vote(self, result):
        assert result.shape[0] == self.tree_num
        voted_result = list(map(lambda x: self._oneVote(x), result.T))
        return np.array(voted_result)

    def _oneVote(self, result):
        assert len(result) == self.tree_num
        count = Counter(result)
        return max(count, key=count.get)

    def score(self, X, Y):
        y_pred = self.predict(X)
        if self.label_type == labelType.binary:
            return classify_f1(y_pred, Y)
        else:
            return classify_f1_micro(y_pred, Y)

    def classifyPlot(self, test_X, test_Y):
        from utils.classify_plot import classify_plot
        classify_plot(self, self.X, self.Y, test_X, test_Y, title='My Random Forest')

if __name__ == '__main__':
    from sklearn.model_selection import train_test_split
    # X, y = get_moon(5000)
    X, y = get_iris()
    X_train,X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
    mrf = MyRandomForest(2)
    mrf.fit(X_train, y_train)
    print(mrf.predict(X_test))
    print(y_test)
    mrf.classifyPlot(X_test, y_test)

