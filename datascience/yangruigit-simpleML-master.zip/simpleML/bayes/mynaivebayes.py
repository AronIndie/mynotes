# -*- coding:utf-8 -*-
import sys
sys.path.append('..')
from abstract.myclassifier import *
from collections import Counter
from utils.score import *
import numpy as np
from dataset.classify_data import *

class MyNaiveBayes(myClassifier):

    def __init__(self):
        super(MyNaiveBayes, self).__init__()

    def fit(self, X, Y):
        self._init(X, Y)
        if self.label_type == labelType.continuous:
            raise Exception("Naive Bayes don't support continuous Y")

        self.is_feature_binary = list(map(lambda x: self._isBinary(x), self.X.T))
        self._fit(self.X, self.Y)

    @staticmethod
    def _isBinary(column):
        keys = np.unique(column)
        if np.array_equal(keys, np.array([0,1])):
            return True
        elif keys.shape[0] == 2:
            raise Exception("Binary features must be inputed as 0 or 1")
        return False

    def _getNormalProb(self, value, mu, sigma2):
        cons = np.sqrt(2 * np.pi)
        return 1 / cons * np.exp(- (value - mu)**2 / (2 * sigma2))

    def _fit(self, X, Y):
        Y_values = np.unique(self.Y)
        self.prob_array = np.zeros((len(Y_values), self.variable_num+1))  # 第一列为标签的先验概率
        self.continuous_record_dict = {}                                  # 用来存储连续变量在prob_array中对应的位置，以及其期望和方差
        for i, y in enumerate(Y_values):
            y_amount = self.Y[self.Y==y].shape[0]
            self.prob_array[i,0] = (y_amount + 1) / (self.sample_num + len(Y_values))  # 拉普拉斯平滑

            for j, is_binary in enumerate(self.is_feature_binary):
                feature_series = self.X[self.Y == y ,j]    # 此时只有0或1元素，只记录1的概率，0的概率用1减去
                if is_binary:
                    self.prob_array[i, j+1] = (np.sum(feature_series) + 1) / (y_amount + len(np.unique(self.X[:,j])))
                else:
                    mu = np.mean(feature_series)
                    sigma2 = np.var(feature_series)
                    self.prob_array[i, j+1] = -1
                    self.continuous_record_dict[(i, j+1)] = (mu, sigma2)

    def predict(self, X):
        return np.array(list(map(lambda x: self._predictSingleSample(x), X)))

    def _predictSingleSample(self, x):
        # 1. 更新prob_array中连续变量的取值
        p = np.ones(self.prob_array.shape[0])
        for i in range(self.prob_array.shape[0]):
            p *= self.prob_array[i, 0]    # 先验先乘进去
            for j in range(1, self.prob_array.shape[1]):
                if self.prob_array[i, j] == -1:
                    mu, sigma2 = self.continuous_record_dict[(i, j)]
                    p[i] *= self._getNormalProb(x[j-1], mu, sigma2)
                else:
                    if x[j-1] == 1:
                        p[i] *= self.prob_array[i, j]
                    else:
                        p[i] *= (1 - self.prob_array[i, j])
        return np.argmax(p)

    def score(self, X, Y):
        y_pred = self.predict(X)
        if self.label_type == labelType.binary:
            return classify_f1(y_pred, Y)
        else:
            return classify_f1_macro(y_pred, Y)

    def classifyPlot(self, X, Y):
        from utils import classify_plot
        classify_plot.classify_plot(self, self.X, self.Y, X, Y, title='My Naive Bayes')

if __name__ == '__main__':

    X = np.array([[0, 0, 0, 1],
           [0, 1, 0, 0],
           [1, 1, 0, 1],
           [0, 1, 1, 1],
           [0, 0, 0, 0]])
    y = np.array([0,1,0,1,0])
    nb = MyNaiveBayes()
    nb.fit(X, y)
    X_test = np.array([0, 0, 0, 0]).reshape(1, -1)
    print(nb.predict(X_test))

