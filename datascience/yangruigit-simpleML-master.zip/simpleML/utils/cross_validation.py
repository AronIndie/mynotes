# -*- coding:utf-8 -*-

import numpy as np
from sklearn.model_selection import train_test_split
from enum import Enum
from collections import defaultdict

class CrossValidationType(Enum):
    holdout = 0
    k_folder = 1

def cross_validation(model, X, y, method=CrossValidationType.holdout, test_size=0.3, cv=5):
    result = np.zeros(cv)
    if method == CrossValidationType.holdout:
        for i in range(cv):
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size)
            model.fit(X_train, y_train)
            result[i] = model.score(X_test, y_test)
        return result
    else:
        ids = np.arange(X.shape[0])
        ids_random = np.random.choice(ids, len(ids), False)
        ids_split = [[] for i in range(cv)]
        for idx in ids_random:
            group_num = idx % cv
            ids_split[group_num].append(idx)

        for i, group in enumerate(ids_split):
            X_test, y_test = X[group], y[group]
            train_ids = sum([i for i in ids_split if i != group], [])
            X_train, y_train = X[train_ids], y[train_ids]
            model.fit(X_train, y_train)
            result[i] = model.score(X_test, y_test)
        return result