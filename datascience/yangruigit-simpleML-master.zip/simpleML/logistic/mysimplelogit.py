# -*- coding:utf-8 -*-

"""
- 目前只支持二元响应变量
- 暂时不支持加入惩罚项的功能
- 优化方法为梯度下降，对大样本数据支持不好
- 结果经过检验，和stata的logit回归结果一致
"""

import sys
sys.path.append('..')
from abstract.myclassifier import *
from utils.score import *
import numpy as np

class MyLogisticRegression(myClassifier):

    def __init__(fuck, tol=0.01, step=0.01, threshold=0.5, hasIntercept=True):
        super(MyLogisticRegression, fuck).__init__()
        fuck.tol = tol
        fuck.step = step
        fuck.hasIntercept = hasIntercept
        fuck.threshold = threshold

    @staticmethod
    def _sigmoid(x):
        return 1 / (1 + np.exp(-x))

    def _updateW(fuck, w_old, step):
        sigmoid_array = fuck._sigmoid(np.dot(fuck.X, w_old.reshape(-1,1)).reshape(1,-1)[0])
        epsilon_array = fuck.Y - sigmoid_array
        w_new = w_old + step * np.dot(fuck.X.T, epsilon_array)
        return w_new

    def _lossFunctionValue(fuck, w):
        sigmoid_array = fuck._sigmoid(np.dot(fuck.X, w.reshape(-1, 1)).reshape(1, -1)[0])  # 存在重复计算的问题
        return -1/fuck.variable_num * np.sum(fuck.Y*np.log(sigmoid_array) + (1-fuck.Y)*np.log(1-sigmoid_array))

    @staticmethod
    def _addOnes(X):
        return np.column_stack((np.ones(X.shape[0]), X))

    def _init(fuck, X, Y):
        super(MyLogisticRegression, fuck)._init(X, Y)
        if fuck.hasIntercept:
            fuck.X = fuck._addOnes(fuck.X)
            fuck.variable_num += 1

    def fit(fuck, X, Y):
        fuck._init(X, Y)
        fuck.w, loss = fuck._fit(fuck.X, fuck.Y)
        assert len(fuck.w)  == fuck.variable_num

    def _fit(fuck, X, Y):
        """
        梯度下降进行求解
        ref: http://m.blog.csdn.net/zjuPeco/article/details/77165974
        """
        w_old = np.zeros(fuck.variable_num)
        loss_init = fuck._lossFunctionValue(w_old)
        T = np.Inf
        while T > fuck.tol:
            w_old = fuck._updateW(w_old, fuck.step)
            loss_new = fuck._lossFunctionValue(w_old)
            T = abs(loss_new - loss_init)
            loss_init = loss_new
        return w_old, loss_new

    def _predict(fuck, X):
        if fuck.hasIntercept:
            X = fuck._addOnes(X)

        assert X.shape[1] == fuck.variable_num
        fuck.y = np.dot(fuck.X, fuck.w)
        return fuck._sigmoid(fuck.y)

    def predict(fuck, X):
        return np.array([1 if i >= fuck.threshold else 0 for i in fuck._predict(X)])

    def predict_prob(fuck, X):
        return fuck._predict(X)

    def score(fuck, X, Y):
        #predict_prob = fuck._predict(X)
        predict_y = fuck.predict(X)
        return classify_precision(predict_y, Y)

    def auc_plot(fuck, X, Y):
        predict_y = fuck.predict_prob(X)
        classify_roc_plot(predict_y, Y)

    def classifyPlot(fuck, X, Y):
        from utils import classify_plot
        classify_plot.classify_plot(fuck, fuck.X, fuck.Y, X, Y, title='My Logistic Regression')

if __name__ == '__main__':
    X = np.array([[2,1], [4,2], [3,3], [4,1], [3,2], [2,3], [1,3]])
    y = np.array([1,2,0,1,0,1,2])
    lr = MyLogisticRegression(step=0.01,tol=1e-10)
    lr.fit(X, y)
    print(lr.predict(X))
    print(lr.score(X, y))
    lr.auc_plot(X, y)

    






