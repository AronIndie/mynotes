# -*- coding:utf-8 -*-

from abc import ABCMeta, abstractmethod
import numpy as np
import pandas as pd
from enum import Enum
from collections import Counter

class labelType(Enum):
    binary = 1
    multiclass = 2
    continuous = 3

class myClassifier(object):

    __metaclass__ = ABCMeta

    def __init__(self):
        pass

    def _init(self, X, Y):
        self._clear()
        X_sample_num = self._checkX(X)
        Y_sample_num = self._checkY(Y)
        assert X_sample_num == Y_sample_num, ValueError
        self.sample_num = X_sample_num
        self.variable_num = X.shape[1]
        self.X = np.array(X)
        self.Y = Y
        self.label_type = self._checkLabelType(self.Y)

    def _clear(self):
        self.X = None
        self.Y = None
        self.sample_num = 0
        self.variable_num = 0

    @staticmethod
    def _checkX(X):
        if isinstance(X, np.ndarray) or isinstance(X, pd.DataFrame):
            assert len(X.shape) == 2
            return X.shape[0]
        else:
            raise TypeError

    @staticmethod
    def _checkY(Y):
        if isinstance(Y, np.ndarray) or isinstance(Y, pd.Series):
            assert len(Y.shape) == 1
            return len(Y)
        else:
            raise TypeError

    @staticmethod
    def _checkLabelType(Y):
        count = dict(Counter(Y))
        if len(count) == 2:
            return labelType.binary
        elif len(count) > len(Y)/2:
            return labelType.continuous
        else:
            return labelType.multiclass

    @abstractmethod
    def fit(self, X, Y):
        pass

    @abstractmethod
    def predict(self, X):
        pass

    @abstractmethod
    def score(self, X, Y):
        pass
