# -*- coding:utf-8 -*-

"""
filter方法进行特征选择
"""
import sys
sys.path.append('../')
import numpy as np
from enum import Enum
from abstract.myclassifier import labelType
from collections import Counter

class FilterType(Enum):
    var = 0
    corr = 1
    chi2 = 3
    entropy = 4

class MyFilter(object):

    def __init__(self, filter_type, top_k):
        self.filterType = filter_type
        self.top_k = top_k

    def _varSelect(self):
        variance_array = list(map(lambda x: np.var(x), self.X.T))
        self._getTopKIds(variance_array)

    def _corrSelect(self):
        func = lambda x, y: np.corrcoef(x, y)
        corr_array = list(map(lambda x: func(x, self.Y)[0][1], self.X.T))
        self._getTopKIds(corr_array)

    def _chiSelect(self):
        """
        卡方检验用以检验两个事件是否独立，ref: http://blog.csdn.net/yihucha166/article/details/50646615
        检验统计量越大表示越有相关性
        """
        from sklearn.feature_selection import chi2
        chi2_array = chi2(self.X, self.Y)[0]
        self._getTopKIds(chi2_array)

    def _entropySelect(self):
        """
        互信息法
        """
        from minepy import MINE
        m = MINE()
        mic_array = np.zeros(self.sample_num)
        for i,x in enumerate(self.X.T):
            m.compute_score(x, self.Y)
            mic_array[i] = m.mic()
        self._getTopKIds(mic_array)

    def _getTopKIds(self, value_array, choose_max=True):
        """
        根据输入的数组，得到前k个最大或者是最小值对应的ids
        如果是要选择对应值最大的，则默认参数，否则改为False
        """
        pair = list(zip(range(self.variable_num), value_array))

        if choose_max:
            pair = sorted(pair, key=lambda x:x[1], reverse=True)
        else:
            pair = sorted(pair, key=lambda x:x[1])

        self._selectIds = np.array(list(zip(*pair))[0][:self.top_k])

    @staticmethod
    def _checkLabelType(Y):
        count = dict(Counter(Y))
        if len(count) == 2:
            return labelType.binary
        elif len(count) > len(Y)/2:
            return labelType.continuous
        else:
            return labelType.multiclass

    def _check(self, X, Y):
        assert X.shape[0] == Y.shape[0]
        assert len(Y.shape) == 1
        self.label_type = self._checkLabelType(Y)
        self.X = X
        self.Y = Y
        self.sample_num = X.shape[0]
        self.variable_num = X.shape[1]
        assert self.top_k < self.variable_num
        self._selectIds = np.zeros(self.top_k)

    def fit(self, X, Y=None):
        """
        返回当前选择X的列编号
        - 输入X要么是连续，要么是0-1，不存在多分类
        - 输入Y可以使连续，0-1或是多分类
        """
        self._check(X, Y)
        if self.filterType == FilterType.var:
            self._varSelect()
        elif self.filterType == FilterType.corr:
            if self.label_type == labelType.multiclass:
                raise Exception("多分类变量不支持相关系数，请尝试卡方检验法")
            self._corrSelect()
        elif self.filterType == FilterType.chi2:
            if self.label_type == labelType.continuous:
                raise Exception("连续变量不支持卡方检验，请尝试相关系数法")
            self._chiSelect()
        elif self.filterType == FilterType.entropy:
            self._entropySelect()

    def transform(self, X):
        return X[:, self._selectIds]

    def fitTransform(self, X, Y):
        self.fit(X, Y)
        return self.transform(X)

if __name__ == '__main__':
    np.random.seed(918)
    X = np.random.random(120).reshape(-1, 4)
    np.random.seed(918)
    Y = np.random.randint(0,3,30)
    mf = MyFilter(filter_type=FilterType.chi2, top_k=3)
    print(mf.fitTransform(X,Y))