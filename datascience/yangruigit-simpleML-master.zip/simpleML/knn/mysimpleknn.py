# -*- coding:utf-8 -*-


import sys
sys.path.append('..')
from abstract.myclassifier import *
from enum import Enum
from utils.score import *
import numpy as np


class DisType(Enum):
    Eculidean = 1
    Manhattan = 2
    Minkowski = 3               # 明可夫斯基距离
    Chebyshev = 4               # 切比雪夫距离
    CosSim = 5                  # 余弦角距离

class myKNN(myClassifier):

    def __init__(self, K=1, distance_type=DisType.Eculidean):
        super(myKNN, self).__init__()
        self.K = K
        self.dist_type = distance_type

    def fit(self, X, Y):
        self._init(X, Y)
        self._fit(X, Y)

    def _fit(self, X, Y):
        """
        由于是惰性学习，此处无需做任何事
        """
        pass

    def predict(self, X, K=None, dist_type=None):
        if K == None: K =self.K
        if dist_type == None: dist_type = self.dist_type
        dist_func = self._getDistFunc(dist_type)
        return list(map(lambda i: self._predictSingleSample(i, K, dist_func), X))

    def _predictSingleSample(self, x, K, dist_func):
        sim_list = list(map(lambda i: dist_func(x, i), self.X))
        sim_y_list = zip(sim_list, self.Y)
        selected_sim_y = sorted(sim_y_list, key=lambda x:x[0], reverse=False)[:K]
        return self._vote([i[1] for i in selected_sim_y])

    @staticmethod
    def _vote(y_list):
        count_dict = dict(Counter(y_list))
        return max(count_dict, key=count_dict.get)

    @staticmethod
    def _getDistFunc(dist_type):

        if dist_type == DisType.Eculidean:
            # 向量相减的2范数，就是马氏距离
            return lambda X1, X2: np.linalg.norm(X1-X2, 2)
        elif dist_type == DisType.Manhattan:
            return lambda X1, X2: np.linalg.norm(X1-X2, 1)
        elif dist_type == DisType.Chebyshev:
            return lambda X1, X2: np.linalg.norm(X1-X2, np.inf)
        elif dist_type == DisType.CosSim:
            return lambda X1, X2: -np.dot(X1,X2) / (np.linalg.norm(X1,2) * np.linalg.norm(X2, 2))
        else:
            raise Exception("no such method")

    def score(self, X, Y, K=None, dist_type=None):
        y_predict = self.predict(X, K, dist_type)
        count_dict = dict(Counter(y_predict))
        if len(count_dict) <= 2:
            # binary classifyn
            f1_score = classify_f1(y_predict, Y)
        else:
            f1_score = classify_f1_macro(y_predict, Y)
        return f1_score

    def classifyPlot(self, X, Y):
        from utils import classify_plot
        classify_plot.classify_plot(self, self.X, self.Y, X, Y, title='My KNN')

if __name__ == '__main__':
    from dataset.classify_data import get_iris
    from sklearn.model_selection import train_test_split
    knn_test = myKNN(K=3, distance_type=DisType.CosSim)
    X, y = get_iris()
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.3)
    knn_test.fit(X_train, y_train)

    from sklearn.neighbors import KNeighborsClassifier

    knn_sklearn = KNeighborsClassifier(n_neighbors=3)
    knn_sklearn.fit(X_train, y_train)

    print(knn_test.predict(X_test))
    print(list(knn_sklearn.predict(X_test)))
    print(list(y_test))
    print(knn_test.score(X_test, y_test))
    print(knn_sklearn.score(X_test, y_test))

