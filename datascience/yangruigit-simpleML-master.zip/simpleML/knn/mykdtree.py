# -*- coding:utf-8 -*-

import sys
sys.path.append('..')
from abstract.myclassifier import *
from enum import Enum
from collections import Counter
from utils.score import *
import numpy as np
from mysimpleknn import DisType, myKNN

class node:

    __slot__ = ['left', 'right','parent', 'value', 'dimension', 'sampleIds']

    def __init__(self, left, right, parent, value, dimension, sampleIds):
        self.left = left
        self.right = right
        self.value = value
        self.parent = parent
        self.dimension = dimension
        self.sampleIds = sampleIds

class myKDTree(myKNN):

    def __init__(self, K=5, dist_type=DisType.Eculidean):
        super(myKDTree, self).__init__(K, dist_type)

    def _chooseSplitFeature(self, X, ids):
        X = X[ids]
        variance_list = list(map(lambda x: np.var(x), X.T))
        split_feature_id =  variance_list.index(max(variance_list))
        median = np.median(X.T[split_feature_id])
        # split_node = node(None, None, median, split_feature_id, ids)
        return split_feature_id, median

    def _fit(self, X, Y):
        """
        此处建KD树
        """
        self.root_node = node(None, None, None, None, None, np.arange(self.X.shape[0]))
        self._buildKDTree(self.root_node, 0)

    def _buildKDTree(self, input_node:node, depth) -> node:
        if len(input_node.sampleIds) == 0:
            return None

        sample_ids = input_node.sampleIds
        feat_id, median = self._chooseSplitFeature(self.X, input_node.sampleIds)
        input_node.value = median # sample_ids[self.X[sample_ids, feat_id]==median]
        input_node.dimension = feat_id
        left_ids = sample_ids[self.X[sample_ids,feat_id]<median]
        left_node = node(None, None, input_node, None, None,left_ids)
        right_ids = sample_ids[self.X[sample_ids,feat_id]>median]
        right_node = node(None, None, input_node, None, None, right_ids)
        input_node.left = self._buildKDTree(left_node, depth+1)
        input_node.right = self._buildKDTree(right_node, depth+1)
        return input_node

    def _predictSingleSample(self, x, K, dist_func):
        """
        1 . 从root节点开始，DFS搜索直到叶子节点，同时在stack中顺序存储已经访问的节点。
        2. 如果搜索到叶子节点，当前的叶子节点被设为最近邻节点。
        3. 然后通过stack回溯:
        4. 如果当前点的距离比最近邻点距离近，更新最近邻节点.
        5. 然后检查以最近距离为半径的圆是否和父节点的超平面相交.
        6. 如果相交，则必须到父节点的另外一侧，用同样的DFS搜索法，开始检查最近邻节点。
        7. 如果不相交，则继续往上回溯，而父节点的另一侧子节点都被淘汰，不再考虑的范围中.
        8. 当搜索回到root节点时，搜索完成，得到最近邻节点。
        """
        pass


    def _searchKDTree(self, x, the_node:node, dist_func):
        if x[the_node.dimension] == the_node.value:
            return the_node

        if the_node.left == None and the_node.right == None:
            return the_node

        if x[the_node.dimension] < the_node.value:
            return self._searchKDTree(x, the_node.left)
        else:
            return self._searchKDTree(x, the_node.right)

        return None

    def _backTrace(self, x, theNode:node, bestNode:node):
        # 如果x和node的父节点不相交，则一直往上回溯到近邻节点
        node_ids = theNode.sampleIds[self.X[:,theNode.dimension]==theNode.value]
        split_point = self.X[node_ids[0]]
        # 如果x和node的父节点相交，则要回溯父节点的另一分支
        # 写不动了


if __name__ == '__main__':
    pass





