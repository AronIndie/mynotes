# -*- coding:utf-8 -*-

# from feature_engineering.filter_select import *
# X = np.random.random(20).reshape(-1, 4)
# Y = np.random.randint(0,2,5)
# mf = MyFilter(filter_type=FilterType.chi2, top_k=3)
# mf.fitTransform(X,Y)
# mf.transform(X)

# from utils.score import *
# print(classify_accuracy(np.array([1,0,1]), np.array([1, 1, 1])))

# from utils.cross_validation import *
# cross_validation(model, X, y, CrossValidationType.holdout, 0.3, 5)

from knn.mysimpleknn import *
from logistic.mysimplelogit import *
from tree.myrandowforest import *
from svm.mysimplesvm import *
from cluster.hierarchical import *
from cluster.kmeans import *
from bayes.mynaivebayes import *