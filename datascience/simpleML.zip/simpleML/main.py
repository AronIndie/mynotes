# -*- coding:utf-8 -*-

from simple_ml.bp_network import *
from simple_ml.knn import *
from simple_ml.cluster import *
from simple_ml.logistic import *
from simple_ml.naive_bayes import *
from simple_ml.svm import *
from simple_ml.tree import *
